package com.example.helpcentreattendanceapp;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class ManualAttendanceEntryActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextStudentNumber;
    private Button buttonSubmit;
    private Button buttonOpenDatePicker;
    private String selectedDate = "";

    float x1,x2,y1,y2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual_attendance_entry);

        // page header adjustments
        getSupportActionBar().setTitle("Manual Attendance Entry");
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.truBlue)));

        editTextName = findViewById(R.id.editTextName);
        editTextStudentNumber = findViewById(R.id.editTextStudentNumber);
        buttonSubmit = findViewById(R.id.buttonSubmit);
        buttonOpenDatePicker = findViewById(R.id.buttonOpenDatePicker);

        // Set a click listener for the "Select Date" button
        buttonOpenDatePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerPopup();
            }
        });

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString();
                String studentNumber = editTextStudentNumber.getText().toString();

                String message = "You are on the attendance list.\n\nName: " + name + "\nStudent Number: " + studentNumber;

                if (!selectedDate.isEmpty()) {
                    message += "\nDate: " + selectedDate;
                }

                new AlertDialog.Builder(ManualAttendanceEntryActivity.this)
                        .setTitle("Attendance Confirmation")
                        .setMessage(message)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
    }

    private void showDatePickerPopup() {
        // Create a DatePickerDialog to show the date picker
        DatePickerDialog datePickerDialog = new DatePickerDialog(ManualAttendanceEntryActivity.this);
        datePickerDialog.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                // Handle the selected date, if needed
                selectedDate = year + "-" + (month + 1) + "-" + dayOfMonth; // Format the selected date
            }
        });
        datePickerDialog.show();
    }

    // swipe to each activity
    public boolean onTouchEvent(MotionEvent touchEvent) {
        switch (touchEvent.getAction()) {
            case MotionEvent.ACTION_DOWN:
                x1 = touchEvent.getX();
                y1 = touchEvent.getY();
                break;
            case MotionEvent.ACTION_UP:
                x2 = touchEvent.getX();
                y2 = touchEvent.getY();
                if (x1 < x2) { // left swipe to back to QR scan main page
                    Intent i = new Intent(ManualAttendanceEntryActivity.this, MainActivity.class);
                    startActivity(i);
                }
                break;
        }
        return false;
    }
}
