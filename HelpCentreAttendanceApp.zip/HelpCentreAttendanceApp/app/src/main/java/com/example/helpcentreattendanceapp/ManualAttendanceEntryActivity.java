package com.example.helpcentreattendanceapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class ManualAttendanceEntryActivity extends AppCompatActivity {

    private EditText editTextName;
    private EditText editTextStudentNumber;
    private DatePicker datePicker;
    private Button buttonSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual_attendance_entry);

        editTextName = findViewById(R.id.editTextName);
        editTextStudentNumber = findViewById(R.id.editTextStudentNumber);
        datePicker = findViewById(R.id.datePicker);
        buttonSubmit = findViewById(R.id.buttonSubmit);

        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editTextName.getText().toString();
                String studentNumber = editTextStudentNumber.getText().toString();
                String selectedDate = datePicker.getYear() + "-" + (datePicker.getMonth() + 1) + "-" + datePicker.getDayOfMonth();

                String message = "You are on the attendance list.\n\nName: " + name + "\nStudent Number: " + studentNumber + "\nSelected Date: " + selectedDate;

                // Display an alert dialog with the message
                new AlertDialog.Builder(ManualAttendanceEntryActivity.this)
                        .setTitle("Attendance Confirmation")
                        .setMessage(message)
                        .setPositiveButton("OK", null)
                        .show();
            }
        });
    }
}