package com.example.helpcentreattendanceapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class HelpDeskScheduleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_desk_schedule);
    }
}