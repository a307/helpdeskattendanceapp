package com.example.helpcentreattendanceapp;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MotionEvent;

import androidx.appcompat.app.AppCompatActivity;

public class HelpDeskScheduleActivity extends AppCompatActivity {

    float x1,x2,y1,y2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_desk_schedule);

        // page header adjustments
        getSupportActionBar().setTitle("Help Desk Schedule");
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.truBlue)));
    }

    // swipe to each activity
    public boolean onTouchEvent(MotionEvent touchEvent) {
        switch (touchEvent.getAction()) {
            case MotionEvent.ACTION_DOWN:
                x1 = touchEvent.getX();
                y1 = touchEvent.getY();
                break;
            case MotionEvent.ACTION_UP:
                x2 = touchEvent.getX();
                y2 = touchEvent.getY();
                if (x1 > x2) { // right swipe back to QR scan main page
                    Intent i = new Intent(HelpDeskScheduleActivity.this, MainActivity.class);
                    startActivity(i);
                }
                break;
        }
        return false;
    }
}